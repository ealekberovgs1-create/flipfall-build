# Сборка APK FLIPFALL (v1.1)

Нужны: Node 20+, JDK 21, Android SDK (platform 36, build-tools), интернет для npm/Gradle.

```bash
npm install
npm install --prefix apk
npx vite build --config vite.apk.config.ts      # собирает веб-часть в apk/dist
cd apk && npx cap sync android                  # копирует dist в Android-проект
cd android
# в local.properties укажи свои пути sdk.dir= и (если нужно) org.gradle.java.home в gradle.properties
./gradlew assembleDebug                         # APK: app/build/outputs/apk/debug/app-debug.apk
```

Для публикации: `./gradlew assembleRelease` и подпись своим keystore.
