import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.flipfall.game',
  appName: 'FLIPFALL',
  webDir: 'dist'
};

export default config;
