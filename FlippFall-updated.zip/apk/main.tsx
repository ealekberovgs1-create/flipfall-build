import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Flipfall } from "../src/game/Flipfall";
import "./app.css";

const root = document.getElementById("root");
if (!root) throw new Error("Не найден корень приложения");

createRoot(root).render(
  <StrictMode>
    <Flipfall />
  </StrictMode>,
);
