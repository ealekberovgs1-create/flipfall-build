import { R, SPIKE_IN, WORLD_W } from "./constants";
import type { Skin } from "./skins";
import type { LiveSeg, World } from "./world";

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  r: number;
  color: string;
};

type Floater = {
  x: number;
  y: number;
  vy: number;
  text: string;
  color: string;
  life: number;
  max: number;
};

type Ring = { x: number; y: number; life: number; max: number; r: number; color: string };

type Trail = { x: number; y: number; life: number; max: number };

const NEON = "#2ee6b5";
const GOLD = "#ffc24b";
const SPIKE = "#ff4d6a";

function hash01(n: number) {
  let x = n | 0;
  x = Math.imul(x ^ (x >>> 16), 0x7feb352d);
  x = Math.imul(x ^ (x >>> 15), 0x846ca68b);
  return ((x ^ (x >>> 16)) >>> 0) / 4294967296;
}

function rr(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  if (w <= 1 || h <= 1) return;
  const rad = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + rad, y);
  ctx.arcTo(x + w, y, x + w, y + h, rad);
  ctx.arcTo(x + w, y + h, x, y + h, rad);
  ctx.arcTo(x, y + h, x, y, rad);
  ctx.arcTo(x, y, x + w, y, rad);
  ctx.closePath();
}

function luma(hex: string) {
  const n = Number.parseInt(hex.slice(1), 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

export class Presentation {
  snapNext = true;
  trauma = 0;
  flash = 0;
  private cam = 0;
  private t = 0;
  private particles: Particle[] = [];
  private floaters: Floater[] = [];
  private trail: Trail[] = [];
  private rings: Ring[] = [];
  private skyKey = "";
  private skyGrad: CanvasGradient | null = null;
  private glowGrad: CanvasGradient | null = null;
  private vigCanvas: HTMLCanvasElement | null = null;
  private vigKey = "";
  /** 1 = full quality, lower values drop optional effects on weak devices. */
  quality = 1;
  private slow = 0;
  private fast = 0;

  /** Adaptive quality: call once per frame with the raw frame time. */
  tune(dt: number) {
    if (dt > 0.026) {
      this.slow++;
      this.fast = 0;
    } else if (dt < 0.019) {
      this.fast++;
      this.slow = Math.max(0, this.slow - 1);
    }
    if (this.slow > 45 && this.quality > 0.4) {
      this.quality = Math.max(0.4, this.quality - 0.3);
      this.slow = 0;
    } else if (this.fast > 600 && this.quality < 1) {
      this.quality = Math.min(1, this.quality + 0.3);
      this.fast = 0;
    }
  }

  reset() {
    this.snapNext = true;
    this.trauma = 0;
    this.flash = 0;
    this.particles = [];
    this.floaters = [];
    this.trail = [];
    this.rings = [];
  }

  ring(x: number, y: number, color: string, r = 34) {
    if (this.quality < 0.5) return;
    if (this.rings.length > 6) this.rings.shift();
    this.rings.push({ x, y, life: 0.42, max: 0.42, r, color });
  }

  burst(x: number, y: number, color: string, count: number, speed: number) {
    const n = Math.max(2, Math.round(count * (0.4 + this.quality * 0.6)));
    for (let i = 0; i < n; i++) {
      if (this.particles.length > 140) this.particles.shift();
      const a = Math.random() * Math.PI * 2;
      const s = speed * (0.35 + Math.random());
      const life = 0.28 + Math.random() * 0.4;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life,
        max: life,
        r: 1.4 + Math.random() * 2.4,
        color,
      });
    }
  }

  popup(x: number, y: number, text: string, color: string) {
    if (this.floaters.length > 14) this.floaters.shift();
    this.floaters.push({ x, y: y + 16, vy: 48, text, color, life: 0.85, max: 0.85 });
  }

  frame(
    ctx: CanvasRenderingContext2D,
    world: World,
    skin: Skin,
    w: number,
    h: number,
    dpr: number,
    dt: number,
    focus: number,
    reduced: boolean,
  ) {
    this.t += dt;
    const worldToPx = w / WORLD_W;
    const viewH = h / worldToPx;
    const target = world.player.y + viewH * (1 - focus);
    if (this.snapNext) {
      this.cam = target;
      this.snapNext = false;
    } else {
      this.cam += (target - this.cam) * (1 - Math.exp(-dt * 7));
    }
    const camTop = this.cam;
    const yBottom = camTop - viewH;

    this.trauma = Math.max(0, this.trauma - dt * 1.7);
    this.flash = Math.max(0, this.flash - dt * 1.8);
    const mag = reduced ? 0 : this.trauma * this.trauma;
    const shakeX = Math.sin(this.t * 53) * mag * 14 * worldToPx;
    const shakeY = Math.cos(this.t * 41) * mag * 10 * worldToPx;

    const p = world.player;
    if (p.alive) {
      const life = 0.22 + Math.min(0.4, world.combo * 0.045);
      this.trail.push({ x: p.x, y: p.y, life, max: life });
    }
    for (const bit of this.trail) bit.life -= dt;
    if (this.trail.length > 40) this.trail.splice(0, this.trail.length - 40);
    this.trail = this.trail.filter((bit) => bit.life > 0);

    for (const bit of this.particles) {
      bit.life -= dt;
      bit.x += bit.vx * dt;
      bit.y += bit.vy * dt;
      bit.vx *= Math.exp(-dt * 1.6);
      bit.vy *= Math.exp(-dt * 1.6);
    }
    this.particles = this.particles.filter((bit) => bit.life > 0);
    for (const floater of this.floaters) {
      floater.life -= dt;
      floater.y += floater.vy * dt;
    }
    this.floaters = this.floaters.filter((floater) => floater.life > 0);
    for (const ring of this.rings) ring.life -= dt;
    this.rings = this.rings.filter((ring) => ring.life > 0);

    const sx = (x: number) => x * worldToPx;
    const sy = (y: number) => (camTop - y) * worldToPx;

    this.drawSky(ctx, w, h, camTop, viewH, world.player.y);
    ctx.save();
    ctx.translate(shakeX, shakeY);
    this.drawSafe(ctx, world, sx, sy, w);
    this.drawSegments(ctx, world, sx, sy, worldToPx, yBottom, camTop);
    this.drawCoins(ctx, world, sx, sy, worldToPx, yBottom, camTop);
    this.drawRotors(ctx, world, sx, sy, worldToPx, yBottom, camTop);
    this.drawTrail(ctx, world, sx, sy, worldToPx);
    this.drawHint(ctx, world, sx, sy, worldToPx);
    this.drawHero(ctx, world, skin, sx, sy, worldToPx);
    this.drawRings(ctx, sx, sy, worldToPx);
    this.drawParticles(ctx, sx, sy, worldToPx);
    this.drawFloaters(ctx, sx, sy, dpr);
    ctx.restore();
    this.drawVignette(ctx, w, h, world.climb());
    if (this.flash > 0.01) {
      ctx.fillStyle = `rgba(255, 244, 236, ${this.flash * 0.55})`;
      ctx.fillRect(0, 0, w, h);
    }
  }

  private drawSky(
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    camTop: number,
    viewH: number,
    distance: number,
  ) {
    const night = Math.min(1, distance / 9000);
    const nightKey = night > 0.55 ? 1 : 0;
    const key = `${w}x${h}:${nightKey}:${Math.round(night * 20)}`;
    if (key !== this.skyKey) {
      this.skyKey = key;
      const g = ctx.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, nightKey ? "#081018" : "#0e3a4a");
      g.addColorStop(0.55, "#0a2230");
      g.addColorStop(1, "#07141c");
      this.skyGrad = g;
      const glow = ctx.createRadialGradient(w * 0.5, h * 0.22, 10, w * 0.5, h * 0.2, w * 0.7);
      glow.addColorStop(0, `rgba(46, 230, 181, ${0.09 - night * 0.04})`);
      glow.addColorStop(1, "rgba(46, 230, 181, 0)");
      this.glowGrad = glow;
    }
    ctx.fillStyle = this.skyGrad!;
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = this.glowGrad!;
    ctx.fillRect(0, 0, w, h);

    const worldToPx = w / WORLD_W;
    const sy = (y: number) => (camTop - y) * worldToPx;
    const first = Math.floor((camTop - viewH) / 90) - 1;
    const last = Math.floor(camTop / 90) + 1;
    const big = worldToPx > 1.6 ? 1.4 : 1;
    // Parallax layer: far dust drifts slower than the world for depth.
    const far = camTop * 0.45;
    const fFirst = Math.floor((far - viewH) / 140) - 1;
    const fLast = Math.floor(far / 140) + 1;
    if (this.quality > 0.5) {
      ctx.fillStyle = "#9fe9d6";
      for (let i = fFirst; i <= fLast; i++) {
        const n = hash01(i * 131 + 7);
        const x = (0.1 + n * 0.8) * w;
        const y = (far - i * 140) * worldToPx;
        ctx.globalAlpha = 0.1 + n * 0.12;
        ctx.beginPath();
        ctx.arc(x, y, (1.2 + n * 1.2) * big, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    for (let i = first; i <= last; i++) {
      const y = i * 90;
      const screenY = sy(y);
      for (let lane = 0; lane < 3; lane++) {
        const n = hash01(i * 17 + lane * 97);
        if (n < 0.45) continue;
        const x = (0.18 + lane * 0.28 + n * 0.08) * w;
        const r = (1 + n * 1.7) * big;
        const twinkle = this.quality > 0.5 ? 0.75 + 0.25 * Math.sin(this.t * 2 + i + lane) : 1;
        ctx.globalAlpha = (0.25 + n * 0.45) * twinkle;
        ctx.fillStyle = n > 0.8 ? GOLD : "#d5fff4";
        ctx.beginPath();
        ctx.arc(x, screenY, r, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.globalAlpha = 1;
  }

  private drawSafe(
    ctx: CanvasRenderingContext2D,
    world: World,
    _sx: (x: number) => number,
    sy: (y: number) => number,
    w: number,
  ) {
    for (const block of world.blocks) {
      if (!block.safe) continue;
      const top = sy(block.y0 + block.h);
      const bot = sy(block.y0);
      if (bot < 0 || top > ctx.canvas.height) continue;
      const g = ctx.createLinearGradient(0, top, 0, bot);
      g.addColorStop(0, "rgba(46, 230, 181, 0)");
      g.addColorStop(0.5, "rgba(46, 230, 181, 0.07)");
      g.addColorStop(1, "rgba(46, 230, 181, 0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, top, w, bot - top);
    }
  }

  private drawSegments(
    ctx: CanvasRenderingContext2D,
    world: World,
    sx: (x: number) => number,
    sy: (y: number) => number,
    k: number,
    yBottom: number,
    camTop: number,
  ) {
    const list = world.segs;
    for (let pass = 0; pass < 2; pass++) {
      for (const seg of list) {
        const spike = seg.kind === "spike";
        if (pass === 0 ? spike : !spike) continue;
        if (seg.dead || seg.y1 < yBottom - 20 || seg.y0 > camTop + 20) continue;
        this.drawSeg(ctx, world, seg, sx, sy, k);
      }
    }
  }

  private drawSeg(
    ctx: CanvasRenderingContext2D,
    world: World,
    seg: LiveSeg,
    sx: (x: number) => number,
    sy: (y: number) => number,
    k: number,
  ) {
    const face = world.faceOf(seg);
    const outer = seg.side === -1 ? -8 : WORLD_W + 8;
    const x0 = Math.min(face, outer);
    const x1 = Math.max(face, outer);
    const left = sx(x0);
    const right = sx(x1);
    const top = sy(seg.y1 + 1);
    const bot = sy(seg.y0 - 1);
    const pw = right - left;
    const ph = bot - top;
    if (pw < 2 || ph < 2) return;

    const worn = seg.kind === "crumble" ? seg.ridden / seg.crumbleDist : 0;
    ctx.save();
    if (seg.kind === "crumble") ctx.globalAlpha = 0.55 + (1 - worn) * 0.45;

    ctx.fillStyle = "rgba(0, 0, 0, 0.28)";
    const shove = seg.side === -1 ? 8 * (k / (k || 1)) : -8;
    rr(ctx, left + shove, top + 10, pw, ph, 18);
    ctx.fill();

    let body = "#102833";
    let panel = "#173848";
    let neon = NEON;
    if (seg.kind === "spike") {
      body = "#241018";
      panel = "#3a1522";
      neon = SPIKE;
    } else if (seg.kind === "crumble") {
      body = "#2a261c";
      panel = "#3d3626";
      neon = "#e7c27a";
    } else if (seg.kind === "boost") {
      body = "#0e2e2c";
      panel = "#14584e";
      neon = "#7dffe0";
    } else if (seg.move) {
      neon = GOLD;
      panel = "#243848";
    }

    rr(ctx, left, top, pw, ph, 16);
    ctx.fillStyle = body;
    ctx.fill();

    const lipW = Math.min(pw * 0.34, Math.max(10, 18 * (ctx.canvas.width / WORLD_W)));
    ctx.fillStyle = panel;
    if (seg.side === -1) rr(ctx, right - lipW, top, lipW, ph, 12);
    else rr(ctx, left, top, lipW, ph, 12);
    ctx.fill();

    ctx.fillStyle = neon;
    const edge = Math.max(3, 4 * (ctx.canvas.width / WORLD_W));
    if (seg.side === -1) ctx.fillRect(right - edge, top + 6, edge, ph - 12);
    else ctx.fillRect(left, top + 6, edge, ph - 12);

    ctx.fillStyle = "rgba(255,255,255,0.09)";
    ctx.fillRect(left, top, pw, Math.max(2, Math.min(8, ph * 0.12)));
    ctx.fillStyle = "rgba(0,0,0,0.28)";
    ctx.fillRect(left, bot - Math.max(4, ph * 0.08), pw, Math.max(4, ph * 0.08));

    if (seg.kind === "spike") this.drawSpikes(ctx, seg, face, sx, sy, k);
    if (seg.kind === "boost") this.drawChevrons(ctx, seg, face, sx, sy, k, world.time);
    if (seg.kind === "crumble") this.drawCracks(ctx, seg, left, top, pw, ph);
    if (seg.move) {
      ctx.globalAlpha = 0.35 + 0.25 * Math.sin(world.time * seg.moveSpeed + seg.movePhase);
      ctx.fillStyle = GOLD;
      if (seg.side === -1) ctx.fillRect(right - edge * 2, top + 8, edge, ph - 16);
      else ctx.fillRect(left + edge, top + 8, edge, ph - 16);
    }
    ctx.restore();
  }

  private drawSpikes(
    ctx: CanvasRenderingContext2D,
    seg: LiveSeg,
    face: number,
    sx: (x: number) => number,
    sy: (y: number) => number,
    k: number,
  ) {
    const span = Math.max(8, seg.y1 - seg.y0);
    const count = Math.max(1, Math.round(span / 26));
    ctx.fillStyle = SPIKE;
    for (let i = 0; i < count; i++) {
      const y = seg.y0 + ((i + 0.5) * span) / count;
      const tip = seg.side === -1 ? face + SPIKE_IN + 2 : face - SPIKE_IN - 2;
      const half = 11;
      ctx.beginPath();
      ctx.moveTo(sx(face), sy(y - half));
      ctx.lineTo(sx(tip), sy(y));
      ctx.lineTo(sx(face), sy(y + half));
      ctx.closePath();
      ctx.fill();
    }
    void k;
  }

  private drawChevrons(
    ctx: CanvasRenderingContext2D,
    seg: LiveSeg,
    face: number,
    sx: (x: number) => number,
    sy: (y: number) => number,
    k: number,
    time: number,
  ) {
    ctx.strokeStyle = "rgba(125, 255, 224, 0.85)";
    ctx.lineWidth = Math.max(2, k * 0.18);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    const span = seg.y1 - seg.y0;
    const step = 42;
    const shift = (time * 90) % step;
    const inset = seg.side === -1 ? 16 : -16;
    for (let y = seg.y0 + shift; y < seg.y1; y += step) {
      if (y < seg.y0 + 8 || y > seg.y1 - 8) continue;
      const x = face + inset;
      ctx.beginPath();
      ctx.moveTo(sx(x - 8), sy(y - 8));
      ctx.lineTo(sx(x), sy(y));
      ctx.lineTo(sx(x - 8), sy(y + 8));
      ctx.stroke();
    }
    void span;
  }

  private drawCracks(
    ctx: CanvasRenderingContext2D,
    seg: LiveSeg,
    left: number,
    top: number,
    pw: number,
    ph: number,
  ) {
    ctx.strokeStyle = "rgba(20, 14, 8, 0.55)";
    ctx.lineWidth = 1.5;
    const n = 3 + Math.floor(hash01(seg.uid * 13) * 3);
    for (let i = 0; i < n; i++) {
      const a = hash01(seg.uid * 31 + i * 9);
      const b = hash01(seg.uid * 17 + i * 5);
      ctx.beginPath();
      ctx.moveTo(left + pw * (0.2 + a * 0.6), top + ph * (0.15 + b * 0.2));
      ctx.lineTo(left + pw * (0.15 + b * 0.7), top + ph * (0.45 + a * 0.4));
      ctx.stroke();
    }
  }

  private drawCoins(
    ctx: CanvasRenderingContext2D,
    world: World,
    sx: (x: number) => number,
    sy: (y: number) => number,
    k: number,
    yBottom: number,
    camTop: number,
  ) {
    for (const coin of world.coins) {
      if (coin.taken || coin.y < yBottom - 20 || coin.y > camTop + 20) continue;
      const bob = Math.sin(this.t * 5 + coin.x) * 3;
      const x = sx(coin.x);
      const y = sy(coin.y + bob);
      const r = 8 * k;
      if (coin.risk) {
        ctx.beginPath();
        ctx.arc(x, y, r + 6 + Math.sin(this.t * 6) * 2, 0, Math.PI * 2);
        ctx.strokeStyle = "rgba(255, 194, 75, 0.45)";
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      const spin = 0.72 + 0.28 * Math.abs(Math.cos(this.t * 3.2 + coin.x * 0.05));
      ctx.beginPath();
      ctx.ellipse(x, y, r * spin, r * 0.92, 0, 0, Math.PI * 2);
      ctx.fillStyle = GOLD;
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(x, y, r * 0.55, r * 0.5, 0, 0, Math.PI * 2);
      ctx.strokeStyle = "#fff1c2";
      ctx.lineWidth = Math.max(1.5, k * 0.12);
      ctx.stroke();
      ctx.fillStyle = "rgba(255,255,255,0.7)";
      ctx.beginPath();
      ctx.ellipse(x - r * 0.28, y - r * 0.3, r * 0.22, r * 0.14, -0.6, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private drawRotors(
    ctx: CanvasRenderingContext2D,
    world: World,
    sx: (x: number) => number,
    sy: (y: number) => number,
    k: number,
    yBottom: number,
    camTop: number,
  ) {
    for (const rot of world.rotors) {
      if (rot.y < yBottom - rot.len || rot.y > camTop + rot.len) continue;
      const a = rot.phase + world.time * rot.omega;
      const dx = Math.cos(a) * rot.len;
      const dy = Math.sin(a) * rot.len;
      const x = sx(rot.x);
      const y = sy(rot.y);
      ctx.beginPath();
      ctx.arc(x, y, rot.len * k, 0, Math.PI * 2);
      ctx.strokeStyle = "rgba(255, 177, 90, 0.18)";
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(sx(rot.x - dx), sy(rot.y - dy));
      ctx.lineTo(sx(rot.x + dx), sy(rot.y + dy));
      ctx.strokeStyle = "#ffb15a";
      ctx.lineWidth = Math.max(6, rot.thick * k);
      ctx.lineCap = "round";
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(x, y, Math.max(4, 5 * k), 0, Math.PI * 2);
      ctx.fillStyle = "#fff1d6";
      ctx.fill();
    }
  }

  private drawTrail(
    ctx: CanvasRenderingContext2D,
    world: World,
    sx: (x: number) => number,
    sy: (y: number) => number,
    k: number,
  ) {
    if (this.trail.length < 2) return;
    const alpha = 0.15 + Math.min(0.65, world.combo * 0.1);
    ctx.beginPath();
    const first = this.trail[0]!;
    ctx.moveTo(sx(first.x), sy(first.y));
    for (let i = 1; i < this.trail.length; i++) {
      const bit = this.trail[i]!;
      ctx.lineTo(sx(bit.x), sy(bit.y));
    }
    ctx.strokeStyle = `rgba(46, 230, 181, ${alpha})`;
    ctx.lineWidth = (3 + Math.min(10, world.combo * 1.3)) * (k / 4 + 0.25);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();
  }

  private drawHint(
    ctx: CanvasRenderingContext2D,
    world: World,
    sx: (x: number) => number,
    sy: (y: number) => number,
    k: number,
  ) {
    const hint = world.hint;
    if (!hint || !world.player.alive) return;
    const pulse = 0.55 + Math.sin(this.t * 7) * 0.45;
    const x = sx(hint.x);
    const y = sy(hint.y);
    ctx.beginPath();
    ctx.arc(x, y, (12 + pulse * 6) * (k / 3 + 0.4), 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(255, 194, 75, ${0.35 + pulse * 0.55})`;
    ctx.lineWidth = 3;
    ctx.stroke();
    const dir = hint.side === -1 ? -1 : 1;
    const px = sx(world.player.x + dir * 26);
    const py = sy(world.player.y + 6);
    ctx.beginPath();
    ctx.moveTo(px, py - 7);
    ctx.lineTo(px + dir * 10, py);
    ctx.lineTo(px, py + 7);
    ctx.strokeStyle = `rgba(255, 194, 75, ${0.5 + pulse * 0.4})`;
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    ctx.stroke();
  }

  private drawHero(
    ctx: CanvasRenderingContext2D,
    world: World,
    skin: Skin,
    sx: (x: number) => number,
    sy: (y: number) => number,
    k: number,
  ) {
    const p = world.player;
    const stand = p.side === -1 ? Math.PI / 2 : -Math.PI / 2;
    const angle = p.alive && p.grounded ? stand + p.rot : p.rot;
    const stretch = Math.max(0.45, 1 + p.squash * 0.72);
    const syScale = stretch;
    const sxScale = 1 / stretch;
    const breath = p.grounded && p.alive ? 1 + Math.sin(this.t * 3.2) * 0.025 : 1;

    ctx.save();
    ctx.translate(sx(p.x), sy(p.y));
    ctx.rotate(angle);
    ctx.scale(k * sxScale * breath, k * syScale * breath);

    ctx.fillStyle = "rgba(0,0,0,0.25)";
    ctx.beginPath();
    ctx.ellipse(0, R * 0.72, R * 0.72, R * 0.28, 0, 0, Math.PI * 2);
    ctx.fill();

    const wobbleArm = Math.sin(this.t * (p.grounded ? 10 : 16) + p.wobble) * (p.grounded ? 1.4 : 4);
    ctx.fillStyle = skin.limb;
    ctx.beginPath();
    ctx.ellipse(-R * 0.92, -1 + wobbleArm, 4.3, 3.1, -0.5, 0, Math.PI * 2);
    ctx.ellipse(R * 0.92, -1 - wobbleArm, 4.3, 3.1, 0.5, 0, Math.PI * 2);
    ctx.fill();

    ctx.beginPath();
    ctx.ellipse(0, 1, R * 1.05, R * 0.96, 0, 0, Math.PI * 2);
    ctx.fillStyle = skin.body;
    ctx.fill();
    ctx.lineWidth = 1.6;
    ctx.strokeStyle = skin.deep;
    ctx.stroke();

    ctx.fillStyle = skin.belly;
    ctx.globalAlpha = 0.9;
    ctx.beginPath();
    ctx.ellipse(0, 3.2, R * 0.48, R * 0.36, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;

    ctx.fillStyle = "rgba(255,255,255,0.38)";
    ctx.beginPath();
    ctx.ellipse(-4.2, -6.2, 5.2, 3.1, -0.7, 0, Math.PI * 2);
    ctx.fill();

    const foot = p.grounded ? 1 : 0.72;
    ctx.fillStyle = skin.limb;
    ctx.beginPath();
    ctx.ellipse(-6.2, R * 0.78, 5.1, 3.3 * foot, 0.2, 0, Math.PI * 2);
    ctx.ellipse(6.2, R * 0.78, 5.1, 3.3 * foot, -0.2, 0, Math.PI * 2);
    ctx.fill();

    const sprout = Math.sin(this.t * 5 + p.wobble * 4) * 2.4;
    ctx.strokeStyle = skin.antenna;
    ctx.lineWidth = 2;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(1, -R * 0.78);
    ctx.quadraticCurveTo(6, -R * 1.15, sprout, -R * 1.32);
    ctx.stroke();
    ctx.fillStyle = skin.antenna;
    ctx.beginPath();
    ctx.arc(sprout, -R * 1.32, 2.7, 0, Math.PI * 2);
    ctx.fill();

    const worried = p.alive && p.wobble > 0.45;
    const lookX = p.grounded ? (p.side === -1 ? -1.7 : 1.7) : p.grav * 1.2;
    const lookY = worried ? -1.6 : -0.3;
    const eye = luma(skin.body) < 90
      ? { sclera: skin.belly, pupil: skin.deep, shine: "#ffffff" }
      : { sclera: "#fff8f2", pupil: skin.pupil, shine: "#ffffff" };
    this.eye(ctx, -5.6, -3.1, lookX, lookY, eye, p.alive, worried);
    this.eye(ctx, 5.8, -3.3, lookX, lookY, eye, p.alive, worried);

    ctx.fillStyle = skin.blush;
    ctx.globalAlpha = 0.75;
    ctx.beginPath();
    ctx.ellipse(-8.6, 2.4, 2.5, 1.5, 0, 0, Math.PI * 2);
    ctx.ellipse(8.8, 2.5, 2.5, 1.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;

    ctx.strokeStyle = skin.deep;
    ctx.lineWidth = 1.3;
    ctx.lineCap = "round";
    ctx.beginPath();
    if (!p.alive) {
      ctx.moveTo(-3.2, 3.6);
      ctx.quadraticCurveTo(0, 1.2, 3.2, 3.6);
    } else if (worried) {
      ctx.arc(0, 4.6, 2.3, 0, Math.PI * 2);
    } else {
      ctx.arc(0, 2.2, 3.3, 0.15 * Math.PI, 0.85 * Math.PI);
    }
    ctx.stroke();

    if (world.combo > 0 && p.alive) {
      ctx.rotate(-angle);
      ctx.strokeStyle = `rgba(255, 194, 75, ${0.25 + Math.min(0.5, world.combo * 0.06)})`;
      ctx.lineWidth = 2;
      const pulse = 1 + Math.sin(this.t * 8) * 0.04;
      ctx.beginPath();
      ctx.arc(0, 0, (R + 7 + Math.min(8, world.combo)) * pulse, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
  }

  private eye(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    lookX: number,
    lookY: number,
    colors: { sclera: string; pupil: string; shine: string },
    alive: boolean,
    worried: boolean,
  ) {
    const s = worried ? 1.16 : 1;
    if (!alive) {
      ctx.strokeStyle = colors.pupil;
      ctx.lineWidth = 1.7;
      ctx.beginPath();
      ctx.moveTo(x - 3.1, y - 3);
      ctx.lineTo(x + 3.1, y + 3);
      ctx.moveTo(x + 3.1, y - 3);
      ctx.lineTo(x - 3.1, y + 3);
      ctx.stroke();
      return;
    }
    ctx.fillStyle = colors.sclera;
    ctx.beginPath();
    ctx.ellipse(x, y, 4.3 * s, 4.7 * s, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = colors.pupil;
    ctx.beginPath();
    ctx.ellipse(x + lookX, y + lookY, 2.15 * s, 2.45 * s, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = colors.shine;
    ctx.beginPath();
    ctx.arc(x + lookX - 0.8, y + lookY - 1.1, 0.9, 0, Math.PI * 2);
    ctx.fill();
  }

  private drawRings(
    ctx: CanvasRenderingContext2D,
    sx: (x: number) => number,
    sy: (y: number) => number,
    k: number,
  ) {
    for (const ring of this.rings) {
      const t = 1 - ring.life / ring.max;
      const ease = 1 - (1 - t) * (1 - t);
      ctx.globalAlpha = (1 - t) * 0.7;
      ctx.strokeStyle = ring.color;
      ctx.lineWidth = Math.max(1.5, (1 - t) * 3 * (k / 3));
      ctx.beginPath();
      ctx.arc(sx(ring.x), sy(ring.y), ring.r * ease * k * 0.5 + 4, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  private drawParticles(
    ctx: CanvasRenderingContext2D,
    sx: (x: number) => number,
    sy: (y: number) => number,
    k: number,
  ) {
    for (const bit of this.particles) {
      ctx.globalAlpha = Math.max(0, bit.life / bit.max);
      ctx.fillStyle = bit.color;
      ctx.beginPath();
      ctx.arc(sx(bit.x), sy(bit.y), bit.r * (k / 3 + 0.35), 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  private drawFloaters(
    ctx: CanvasRenderingContext2D,
    sx: (x: number) => number,
    sy: (y: number) => number,
    dpr: number,
  ) {
    ctx.textAlign = "center";
    ctx.font = `700 ${Math.round(16 * dpr)}px Outfit, sans-serif`;
    for (const floater of this.floaters) {
      ctx.globalAlpha = Math.max(0, floater.life / floater.max);
      ctx.fillStyle = floater.color;
      ctx.fillText(floater.text, sx(floater.x), sy(floater.y));
    }
    ctx.globalAlpha = 1;
  }

  private drawVignette(ctx: CanvasRenderingContext2D, w: number, h: number, climb: number) {
    const key = `${w}x${h}`;
    if (!this.vigCanvas || this.vigKey !== key) {
      const c = this.vigCanvas ?? document.createElement("canvas");
      c.width = w;
      c.height = h;
      const vctx = c.getContext("2d");
      if (vctx) {
        const g = vctx.createRadialGradient(w * 0.5, h * 0.42, w * 0.2, w * 0.5, h * 0.45, w * 0.78);
        g.addColorStop(0, "rgba(0,0,0,0)");
        g.addColorStop(1, "rgba(0,0,0,0.38)");
        vctx.clearRect(0, 0, w, h);
        vctx.fillStyle = g;
        vctx.fillRect(0, 0, w, h);
      }
      this.vigCanvas = c;
      this.vigKey = key;
    }
    ctx.drawImage(this.vigCanvas, 0, 0);
    const speed = Math.min(1, Math.max(0, (climb - 220) / 180));
    if (speed <= 0.02 || this.quality < 0.5) return;
    ctx.strokeStyle = `rgba(214, 255, 244, ${0.05 + speed * 0.12})`;
    ctx.lineWidth = Math.max(2, w / 220);
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const y = ((this.t * (180 + speed * 220) + i * 97) % (h + 40)) - 20;
      ctx.moveTo(8, y);
      ctx.lineTo(8, y + 28 + speed * 20);
      ctx.moveTo(w - 8, y + 20);
      ctx.lineTo(w - 8, y + 48 + speed * 16);
    }
    ctx.stroke();
  }
}

export function multLabel(combo: number) {
  const m = Math.min(6, 1 + combo * 0.25);
  return m.toLocaleString("ru-RU", { minimumFractionDigits: m % 1 ? 2 : 0, maximumFractionDigits: 2 });
}
