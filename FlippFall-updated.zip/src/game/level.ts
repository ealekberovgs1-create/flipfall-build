import type { Side } from "./constants";

export type Kind = "solid" | "spike" | "crumble" | "boost";

export type SegDef = {
  side: Side;
  y0: number;
  y1: number;
  kind: Kind;
  /** Shift the inner face into the corridor so the piece reads as a platform. */
  inset?: number;
  move?: number;
  moveSpeed?: number;
  movePhase?: number;
  crumbleDist?: number;
};

export type RotorDef = {
  x: number;
  y: number;
  len: number;
  thick: number;
  omega: number;
  phase: number;
};

export type CoinDef = { x: number; y: number; risk?: boolean };

export type ChunkDef = {
  id: string;
  tier: 0 | 1 | 2 | 3;
  h: number;
  safe?: boolean;
  segs: SegDef[];
  rotors?: RotorDef[];
  coins?: CoinDef[];
};

const L: Side = -1;
const R: Side = 1;

function w(
  side: Side,
  y0: number,
  y1: number,
  kind: Kind = "solid",
  extra: Partial<SegDef> = {},
): SegDef {
  return { side, y0, y1, kind, ...extra };
}

function bookend(h: number, entry = 200, exit = 180): SegDef[] {
  return [w(L, 0, entry), w(R, 0, entry), w(L, h - exit, h), w(R, h - exit, h)];
}

export const POCKET: ChunkDef = {
  id: "pocket",
  tier: 0,
  h: 700,
  safe: true,
  segs: [w(L, 0, 700), w(R, 0, 700)],
  coins: [
    { x: 118, y: 230 },
    { x: 246, y: 390 },
    { x: 160, y: 540 },
  ],
};

/**
 * Every chunk is solid on BOTH walls at the bottom and the top, so the
 * stitch is safe no matter which side the player arrives on. Hazards live
 * in the middle and always leave a bot-passable window (see auditAll).
 */
export const CHUNKS: ChunkDef[] = [
  {
    id: "flip-wide",
    tier: 0,
    h: 980,
    segs: [...bookend(980), w(L, 200, 740), w(R, 520, 800)],
    coins: [
      { x: 180, y: 610, risk: true },
      { x: 96, y: 380 },
    ],
  },
  {
    id: "spikes",
    tier: 1,
    h: 1080,
    segs: [
      ...bookend(1080, 200, 180),
      w(L, 200, 380),
      w(L, 380, 540, "spike"),
      w(L, 540, 900),
      w(R, 200, 600),
      w(R, 600, 760, "spike"),
      w(R, 760, 900),
    ],
    coins: [
      { x: 180, y: 450, risk: true },
      { x: 180, y: 690, risk: true },
    ],
  },
  {
    id: "narrow",
    tier: 2,
    h: 1160,
    segs: [
      ...bookend(1160, 210, 190),
      w(L, 210, 640),
      w(L, 820, 970),
      w(R, 460, 900, "solid", { inset: 64 }),
    ],
    coins: [
      { x: 196, y: 560, risk: true },
      { x: 204, y: 700, risk: true },
    ],
  },
  {
    id: "crumble",
    tier: 2,
    h: 1120,
    segs: [
      ...bookend(1120, 210, 190),
      w(L, 210, 380),
      w(L, 600, 930),
      w(R, 280, 880, "crumble", { inset: 50, crumbleDist: 420 }),
    ],
    coins: [{ x: 196, y: 460, risk: true }],
  },
  {
    id: "mover",
    tier: 2,
    h: 1080,
    segs: [
      ...bookend(1080, 210, 190),
      w(L, 210, 420),
      w(L, 420, 610, "spike"),
      w(L, 610, 890),
      w(R, 240, 890, "solid", { move: 48, moveSpeed: 1.65, movePhase: 0.6, inset: 8 }),
    ],
    coins: [{ x: 186, y: 520, risk: true }],
  },
  {
    id: "rotor",
    tier: 2,
    h: 1140,
    segs: [
      ...bookend(1140, 210, 190),
      w(L, 210, 620),
      w(R, 460, 950, "solid", { inset: 16 }),
    ],
    rotors: [{ x: 186, y: 540, len: 70, thick: 10, omega: 2.05, phase: 0.2 }],
    coins: [{ x: 180, y: 540, risk: true }],
  },
  {
    id: "boost",
    tier: 1,
    h: 840,
    segs: [
      w(L, 0, 840, "boost"),
      w(R, 0, 840),
    ],
    coins: [
      { x: 120, y: 300 },
      { x: 240, y: 460 },
      { x: 140, y: 620 },
    ],
  },
  {
    id: "gold",
    tier: 1,
    h: 1040,
    segs: [
      ...bookend(1040, 200, 180),
      w(L, 200, 860),
      w(R, 440, 640, "solid", { inset: 72 }),
      w(R, 640, 790, "spike", { inset: 72 }),
    ],
    coins: [
      { x: 198, y: 490, risk: true },
      { x: 206, y: 550, risk: true },
      { x: 198, y: 610, risk: true },
    ],
  },
  {
    id: "zigzag",
    tier: 3,
    h: 1320,
    segs: [
      ...bookend(1320, 210, 200),
      w(L, 210, 500),
      w(L, 500, 640, "spike"),
      w(L, 640, 1120),
      w(R, 320, 860, "solid", { inset: 30 }),
      w(R, 860, 1020, "spike", { inset: 30 }),
    ],
    coins: [
      { x: 176, y: 430, risk: true },
      { x: 196, y: 760, risk: true },
    ],
  },
  {
    id: "gates",
    tier: 3,
    h: 1240,
    segs: [
      ...bookend(1240, 210, 200),
      w(L, 210, 520, "solid", { inset: 20 }),
      w(L, 700, 1040),
      w(R, 360, 820, "solid", { inset: 36 }),
      w(R, 820, 980, "spike", { inset: 8 }),
    ],
    coins: [{ x: 180, y: 560, risk: true }],
  },
];

export function tierForDistance(distance: number): 0 | 1 | 2 | 3 {
  if (distance < 900) return 0;
  if (distance < 2300) return 1;
  if (distance < 4300) return 2;
  return 3;
}

export function pickChunk(
  distance: number,
  rng: () => number,
  prevId: string,
  forceSafe: boolean,
): ChunkDef {
  if (forceSafe) return POCKET;
  const max = tierForDistance(distance);
  const min = max === 0 ? 0 : ((max - 1) as 0 | 1 | 2);
  let pool = CHUNKS.filter((c) => c.tier <= max && c.tier >= min && c.id !== prevId);
  if (pool.length === 0) pool = CHUNKS.filter((c) => c.id !== prevId);
  const weighted = pool.flatMap((c) => Array.from({ length: c.tier === max ? 3 : 1 }, () => c));
  return weighted[Math.floor(rng() * weighted.length)] ?? POCKET;
}

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
