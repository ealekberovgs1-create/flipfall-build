/** World is a vertical corridor. Y grows upward. Gravity pulls toward a side wall. */
export const WORLD_W = 360;
export const R = 17;
export const LEFT0 = 44;
export const RIGHT0 = 316;
/** Horizontal speed = climb * K, so the flip arc keeps a constant slope. */
export const K = 3.15;
export const CLIMB_MIN = 172;
export const CLIMB_MAX = 398;
export const CLIMB_RAMP = 6200;
export const FLIP_CD = 0.12;
export const FLIP_BUFFER = 0.16;
export const CRUMBLE_DIST = 340;
export const SPIKE_IN = 20;
export const COYOTE = 22;
export const PROBE_PAD = 4;
export const SLIP_COYOTE = 10;
export const STEP = 1 / 60;

export type Side = -1 | 1;

export function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

export function climbSpeed(distance: number) {
  const t = clamp(distance / CLIMB_RAMP, 0, 1);
  const eased = t * t * (3 - 2 * t);
  return CLIMB_MIN + (CLIMB_MAX - CLIMB_MIN) * eased;
}

export function multiplier(combo: number) {
  return Math.min(6, 1 + combo * 0.25);
}
