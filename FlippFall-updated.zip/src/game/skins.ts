export type Skin = {
  id: string;
  name: string;
  blurb: string;
  price: number;
  body: string;
  deep: string;
  belly: string;
  blush: string;
  limb: string;
  antenna: string;
  pupil: string;
  shine: string;
};

export const SKINS: Skin[] = [
  {
    id: "plyuh",
    name: "Плюх",
    blurb: "Коралловый оригинал",
    price: 0,
    body: "#ff6a45",
    deep: "#e23e22",
    belly: "#ffe3c4",
    blush: "#ff8d86",
    limb: "#ff8a62",
    antenna: "#ffd15c",
    pupil: "#1a2330",
    shine: "#fff4ea",
  },
  {
    id: "luzha",
    name: "Лужа",
    blurb: "Мятное желе",
    price: 40,
    body: "#3ee0a0",
    deep: "#14956a",
    belly: "#e7fff4",
    blush: "#9ff0cf",
    limb: "#63ebc0",
    antenna: "#fff4c8",
    pupil: "#123028",
    shine: "#f4fffb",
  },
  {
    id: "ugolek",
    name: "Уголёк",
    blurb: "Тёплый уголёк",
    price: 90,
    body: "#ff8a3d",
    deep: "#c2410c",
    belly: "#ffd7a8",
    blush: "#ffb088",
    limb: "#ff9d57",
    antenna: "#ffe08a",
    pupil: "#2a140c",
    shine: "#fff1df",
  },
  {
    id: "moloko",
    name: "Молоко",
    blurb: "Сливочный комочек",
    price: 150,
    body: "#f4efe6",
    deep: "#d9cbb8",
    belly: "#fffaf3",
    blush: "#ffb7b0",
    limb: "#efe4d4",
    antenna: "#ff8f9a",
    pupil: "#3a2a28",
    shine: "#ffffff",
  },
  {
    id: "chernila",
    name: "Чернила",
    blurb: "Ночная клякса",
    price: 240,
    body: "#243848",
    deep: "#121e2a",
    belly: "#7fd7c4",
    blush: "#3d6a78",
    limb: "#335066",
    antenna: "#7ee0ff",
    pupil: "#e8fff8",
    shine: "#9ad7ff",
  },
  {
    id: "samorod",
    name: "Самород",
    blurb: "Золотая капля",
    price: 380,
    body: "#ffc857",
    deep: "#e09a16",
    belly: "#fff1c9",
    blush: "#ffe08a",
    limb: "#ffd56a",
    antenna: "#fff7d6",
    pupil: "#3a2808",
    shine: "#fffdf4",
  },
  {
    id: "yagoda",
    name: "Ягода",
    blurb: "Спелая ягодка",
    price: 520,
    body: "#ff4d6d",
    deep: "#c81e45",
    belly: "#ffd0da",
    blush: "#ff8fa3",
    limb: "#ff6b86",
    antenna: "#ffe08a",
    pupil: "#2a1018",
    shine: "#ffe8ee",
  },
];

export function skinById(id: string): Skin {
  return SKINS.find((s) => s.id === id) ?? SKINS[0]!;
}
