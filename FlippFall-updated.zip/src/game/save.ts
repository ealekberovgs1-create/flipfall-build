import { SKINS } from "./skins";

export const SAVE_KEY = "flipfall-save";
export const SAVE_VERSION = 1;

export type QuestKind = "flips" | "coins" | "combo" | "score" | "runs";

export type Quest = {
  id: string;
  kind: QuestKind;
  title: string;
  target: number;
  progress: number;
  reward: number;
  claimed: boolean;
};

export type Save = {
  version: number;
  best: number;
  coins: number;
  unlocked: string[];
  selected: string;
  muted: boolean;
  tutorialDone: boolean;
  questsDate: string;
  quests: Quest[];
};

const TITLES: Record<QuestKind, string> = {
  flips: "Смени гравитацию",
  coins: "Собери монеты",
  combo: "Собери серию",
  score: "Набери очки",
  runs: "Заверши забеги",
};

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function makeQuests(date: string): Quest[] {
  const kinds: QuestKind[] = ["flips", "coins", "combo", "score", "runs"];
  const rng = hash(date);
  const picked: QuestKind[] = [];
  let x = rng || 1;
  while (picked.length < 3) {
    x = (Math.imul(x, 1664525) + 1013904223) >>> 0;
    const k = kinds[x % kinds.length]!;
    if (!picked.includes(k)) picked.push(k);
  }
  return picked.map((kind, i) => {
    const roll = (Math.imul(rng + i * 97, 1103515245) >>> 0) % 3;
    const table: Record<QuestKind, [number, number][]> = {
      flips: [
        [20, 12],
        [40, 22],
        [70, 34],
      ],
      coins: [
        [8, 12],
        [16, 22],
        [28, 36],
      ],
      combo: [
        [4, 16],
        [8, 28],
        [12, 40],
      ],
      score: [
        [400, 18],
        [900, 30],
        [1600, 48],
      ],
      runs: [
        [2, 10],
        [3, 16],
        [5, 26],
      ],
    };
    const [target, reward] = table[kind][roll]!;
    return {
      id: `${date}-${kind}`,
      kind,
      title: TITLES[kind],
      target,
      progress: 0,
      reward,
      claimed: false,
    };
  });
}

export function defaultSave(): Save {
  return {
    version: SAVE_VERSION,
    best: 0,
    coins: 0,
    unlocked: [SKINS[0]!.id],
    selected: SKINS[0]!.id,
    muted: false,
    tutorialDone: false,
    questsDate: todayKey(),
    quests: makeQuests(todayKey()),
  };
}

function migrate(raw: Partial<Save> | null): Save {
  const base = defaultSave();
  if (!raw || typeof raw !== "object") return base;
  const next: Save = {
    ...base,
    ...raw,
    version: SAVE_VERSION,
    unlocked:
      Array.isArray(raw.unlocked) && raw.unlocked.length > 0
        ? raw.unlocked.filter((id) => SKINS.some((s) => s.id === id))
        : base.unlocked,
    quests: Array.isArray(raw.quests) ? raw.quests : base.quests,
  };
  if (!next.unlocked.includes(SKINS[0]!.id)) next.unlocked.unshift(SKINS[0]!.id);
  if (!SKINS.some((s) => s.id === next.selected)) next.selected = SKINS[0]!.id;
  if (next.questsDate !== todayKey()) {
    next.questsDate = todayKey();
    next.quests = makeQuests(next.questsDate);
  }
  return next;
}

export function cloneSave(save: Save): Save {
  return {
    ...save,
    unlocked: [...save.unlocked],
    quests: save.quests.map((q) => ({ ...q })),
  };
}

export function loadSave(): Save {
  if (typeof window === "undefined") return defaultSave();
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return defaultSave();
    return migrate(JSON.parse(raw) as Partial<Save>);
  } catch {
    return defaultSave();
  }
}

export function writeSave(save: Save) {
  if (typeof window === "undefined") return;
  try {
    const next = { ...save, version: SAVE_VERSION };
    localStorage.setItem(SAVE_KEY, JSON.stringify(next));
    localStorage.setItem(SAVE_KEY + "-bak", JSON.stringify(next));
  } catch {
    /* private mode / quota — keep playing in memory */
  }
}

export function bumpQuest(save: Save, kind: QuestKind, amount: number) {
  if (amount <= 0) return;
  for (const q of save.quests) {
    if (q.kind !== kind || q.claimed) continue;
    q.progress = Math.min(q.target, q.progress + amount);
  }
}

export function raiseQuest(save: Save, kind: QuestKind, value: number) {
  for (const q of save.quests) {
    if (q.kind !== kind || q.claimed) continue;
    q.progress = Math.min(q.target, Math.max(q.progress, value));
  }
}

export function claimQuest(save: Save, id: string) {
  const q = save.quests.find((item) => item.id === id);
  if (!q || q.claimed || q.progress < q.target) return false;
  q.claimed = true;
  save.coins += q.reward;
  return true;
}
