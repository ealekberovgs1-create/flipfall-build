export class Sfx {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private music: GainNode | null = null;
  private bus: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private next = 0;
  private step = 0;
  muted = false;

  unlock() {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!this.ctx) {
      this.ctx = new AC({ latencyHint: "interactive" });
      this.master = this.ctx.createGain();
      this.music = this.ctx.createGain();
      this.bus = this.ctx.createGain();
      this.music.gain.value = 0.18;
      this.bus.gain.value = 0.85;
      this.music.connect(this.master);
      this.bus.connect(this.master);
      this.master.connect(this.ctx.destination);
      this.master.gain.value = this.muted ? 0 : 1;
      const n = this.ctx.createBuffer(1, this.ctx.sampleRate * 0.4, this.ctx.sampleRate);
      const data = n.getChannelData(0);
      for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
      this.noise = n;
      this.next = this.ctx.currentTime + 0.05;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  /** Release the audio hardware while the app is in the background. */
  suspend() {
    if (this.ctx && this.ctx.state === "running") void this.ctx.suspend();
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (!this.ctx || !this.master) return;
    this.master.gain.setTargetAtTime(muted ? 0 : 1, this.ctx.currentTime, 0.03);
  }

  private tone(
    freq: number,
    dur: number,
    type: OscillatorType,
    gain: number,
    delay = 0,
    slideTo?: number,
  ) {
    if (!this.ctx || !this.bus || this.muted) return;
    const t = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(40, slideTo), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g);
    g.connect(this.bus);
    osc.start(t);
    osc.stop(t + dur + 0.02);
    osc.onended = () => {
      osc.disconnect();
      g.disconnect();
    };
  }

  private burst(dur: number, gain: number, delay = 0) {
    if (!this.ctx || !this.bus || !this.noise || this.muted) return;
    const t = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "highpass";
    filter.frequency.value = 900;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(filter);
    filter.connect(g);
    g.connect(this.bus);
    src.start(t);
    src.stop(t + dur);
    src.onended = () => {
      src.disconnect();
      filter.disconnect();
      g.disconnect();
    };
  }

  flip() {
    this.tone(240, 0.09, "sine", 0.18, 0, 620);
  }

  land() {
    this.tone(160, 0.07, "triangle", 0.16, 0, 90);
    this.burst(0.05, 0.08);
  }

  coin() {
    this.tone(740, 0.07, "sine", 0.14);
    this.tone(1110, 0.1, "sine", 0.12, 0.05);
  }

  combo(n: number) {
    const f = 392 * 2 ** ((Math.min(n, 16) % 12) / 12);
    this.tone(f, 0.12, "triangle", 0.12);
  }

  die() {
    this.tone(280, 0.28, "sawtooth", 0.08, 0, 55);
    this.burst(0.22, 0.16);
  }

  pump(intensity: number) {
    if (!this.ctx || !this.music || this.muted) return;
    if (this.ctx.state !== "running") return;
    const now = this.ctx.currentTime;
    if (this.next < now - 0.05) this.next = now + 0.02;
    const beat = 60 / (90 + intensity * 32);
    const scale = [261.6, 293.7, 329.6, 392, 440];
    while (this.next < now + 0.22) {
      const t = this.next;
      const eighth = this.step;
      if (eighth % 4 === 0) {
        const osc = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(90 + intensity * 20, t);
        osc.frequency.exponentialRampToValueAtTime(48, t + 0.12);
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(0.22, t + 0.01);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
        osc.connect(g);
        g.connect(this.music);
        osc.start(t);
        osc.stop(t + 0.18);
        osc.onended = () => {
          osc.disconnect();
          g.disconnect();
        };
      }
      if (intensity > 0.15 && eighth % 2 === 1) {
        this.burst(0.03, 0.03 + intensity * 0.03);
      }
      if (eighth % 2 === 0 || intensity > 0.55) {
        const note = scale[(eighth * 3 + Math.floor(intensity * 2)) % scale.length]!;
        const osc = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(note * (intensity > 0.7 && eighth % 8 === 4 ? 2 : 1), t);
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(0.045 + intensity * 0.04, t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t + beat * 0.9);
        osc.connect(g);
        g.connect(this.music);
        osc.start(t);
        osc.stop(t + beat);
        osc.onended = () => {
          osc.disconnect();
          g.disconnect();
        };
      }
      this.next += beat / 2;
      this.step++;
    }
  }
}
