import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { ChevronLeft, Coins, Pause, Play, Volume2, VolumeX } from "lucide-react";
import { CLIMB_MAX, CLIMB_MIN, STEP, multiplier } from "./constants";
import { Presentation } from "./render";
import { Sfx } from "./audio";
import {
  bumpQuest,
  claimQuest,
  cloneSave,
  loadSave,
  raiseQuest,
  writeSave,
  type Save,
} from "./save";
import { SKINS, skinById } from "./skins";
import { World } from "./world";

type Phase = "menu" | "play" | "pause" | "dead" | "skins" | "quests";

type DeathInfo = {
  score: number;
  best: number;
  coins: number;
  record: boolean;
  combo: number;
  reason: string;
};

type Hud = { score: number; combo: number; mult: string; coins: number };

const REASONS: Record<string, string> = {
  spike: "Шипы оказались ближе, чем казалось",
  rotor: "Вертушка задела желе",
  void: "Стена кончилась раньше прыжка",
};

const COACH = [
  "",
  "Коснись экрана — желе упадёт на другую стену.",
  "В полёте оно крутится. Стена поймает сама.",
  "Жёлтое кольцо — момент для серии. Долгая пауза её сбрасывает.",
];

function fmt(n: number) {
  return Math.floor(n).toLocaleString("ru-RU");
}

function seedNow() {
  return (Date.now() ^ Math.floor(Math.random() * 0x7fffffff)) >>> 0;
}

declare global {
  interface Window {
    FlipfallNative?: { exit?: () => void; keepAwake?: (on: boolean) => void };
    __flipfall?: () => {
      phase: Phase;
      score: number;
      alive: boolean;
      y: number;
      combo: number;
      coins: number;
    };
  }
}

export function Flipfall() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const saveRef = useRef<Save | null>(null);
  const worldRef = useRef<World | null>(null);
  const sfxRef = useRef<Sfx | null>(null);
  const lookRef = useRef(new Presentation());
  const phaseRef = useRef<Phase>("menu");
  const coachRef = useRef(0);
  const settledRef = useRef(false);
  const reducedRef = useRef(false);
  const showResultRef = useRef(false);

  const [save, setSave] = useState<Save | null>(null);
  const [phase, setPhase] = useState<Phase>("menu");
  const [hud, setHud] = useState<Hud>({ score: 0, combo: 0, mult: "1", coins: 0 });
  const [death, setDeath] = useState<DeathInfo | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [coach, setCoach] = useState(0);
  const [toast, setToast] = useState("");
  showResultRef.current = showResult;

  function go(next: Phase) {
    phaseRef.current = next;
    setPhase(next);
    window.FlipfallNative?.keepAwake?.(next === "play");
  }

  function commit() {
    const current = saveRef.current;
    if (!current) return;
    writeSave(current);
    setSave(cloneSave(current));
  }

  function advanceCoach(next: number) {
    coachRef.current = next;
    setCoach(next);
    const current = saveRef.current;
    if (next === 0 && current && !current.tutorialDone) {
      current.tutorialDone = true;
      commit();
    }
  }

  function bank() {
    if (settledRef.current) return null;
    const world = worldRef.current;
    const current = saveRef.current;
    if (!world || !current) return null;
    settledRef.current = true;
    const score = Math.floor(world.score);
    const record = score > current.best;
    if (record) current.best = score;
    current.coins += world.runCoins;
    bumpQuest(current, "flips", world.flips);
    bumpQuest(current, "coins", world.runCoins);
    bumpQuest(current, "runs", 1);
    raiseQuest(current, "combo", world.maxCombo);
    raiseQuest(current, "score", score);
    if (coachRef.current === 0) current.tutorialDone = true;
    commit();
    return {
      score,
      best: current.best,
      coins: world.runCoins,
      record,
      combo: world.maxCombo,
      reason: REASONS[world.player.diedReason] ?? "Забег оборвался",
    };
  }

  function finishRun() {
    const info = bank();
    if (!info) return;
    setDeath(info);
    setShowResult(false);
    go("dead");
    window.setTimeout(() => {
      if (phaseRef.current === "dead") setShowResult(true);
    }, 680);
  }

  function bootWorld() {
    worldRef.current = new World({ seed: seedNow() });
    lookRef.current.reset();
    settledRef.current = false;
  }

  function unlock() {
    const sfx = sfxRef.current;
    const current = saveRef.current;
    if (!sfx) return;
    if (current) sfx.muted = current.muted;
    sfx.unlock();
    sfx.setMuted(current?.muted ?? false);
  }

  function startRun() {
    const current = saveRef.current;
    if (!current) return;
    unlock();
    const tutorial = !current.tutorialDone;
    worldRef.current = new World({ seed: seedNow(), tutorial });
    lookRef.current.reset();
    settledRef.current = false;
    coachRef.current = tutorial ? 1 : 0;
    setCoach(coachRef.current);
    setDeath(null);
    setShowResult(false);
    setHud({ score: 0, combo: 0, mult: "1", coins: 0 });
    go("play");
  }

  function toMenu() {
    if ((phaseRef.current === "play" || phaseRef.current === "pause") && !settledRef.current) {
      bank();
    }
    coachRef.current = 0;
    setCoach(0);
    setShowResult(false);
    setDeath(null);
    bootWorld();
    go("menu");
  }

  function toggleMute() {
    const current = saveRef.current;
    const sfx = sfxRef.current;
    if (!current || !sfx) return;
    unlock();
    current.muted = !current.muted;
    sfx.setMuted(current.muted);
    commit();
  }

  function pickSkin(id: string) {
    const current = saveRef.current;
    const sfx = sfxRef.current;
    if (!current) return;
    const skin = skinById(id);
    if (current.unlocked.includes(id)) {
      current.selected = id;
      commit();
      return;
    }
    if (current.coins < skin.price) {
      setToast("Не хватает монет");
      window.setTimeout(() => setToast(""), 1400);
      return;
    }
    current.coins -= skin.price;
    current.unlocked.push(id);
    current.selected = id;
    commit();
    sfx?.coin();
  }

  function onClaim(id: string) {
    const current = saveRef.current;
    if (!current || !claimQuest(current, id)) return;
    commit();
    sfxRef.current?.coin();
  }

  useLayoutEffect(() => {
    const loaded = loadSave();
    saveRef.current = loaded;
    setSave(cloneSave(loaded));
    if (!sfxRef.current) {
      const sfx = new Sfx();
      sfx.muted = loaded.muted;
      sfxRef.current = sfx;
    }
    if (!worldRef.current) bootWorld();
    reducedRef.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let alive = true;
    let last = performance.now();
    let acc = 0;
    let hudAcc = 0;
    let coachTime = 0;
    const reducedMq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onReduce = () => {
      reducedRef.current = reducedMq.matches;
    };
    reducedMq.addEventListener("change", onReduce);

    const onVis = () => {
      if (document.visibilityState === "visible") {
        last = performance.now();
        acc = 0;
        if (phaseRef.current !== "play") sfxRef.current?.unlock();
      } else {
        // Backgrounded (call, app switch, screen off): never let the run keep going unseen.
        if (phaseRef.current === "play") go("pause");
        sfxRef.current?.suspend();
      }
    };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("pagehide", onVis);

    // Android back button: Capacitor walks WebView history, so keep one entry to catch it.
    const armBack = () => window.history.pushState({ ff: 1 }, "");
    armBack();
    const onBack = () => {
      const now = phaseRef.current;
      if (now === "play") go("pause");
      else if (now === "skins" || now === "quests") go("menu");
      else if (now === "pause") toMenu();
      else if (now === "dead") toMenu();
      else {
        // Menu: a second press leaves the game.
        if (backArmed) {
          // Second press: leave via the native bridge; without it, let the OS handle the next press.
          if (window.FlipfallNative?.exit) window.FlipfallNative.exit();
          return;
        }
        backArmed = true;
        setToast("Нажми «Назад» ещё раз, чтобы выйти");
        window.setTimeout(() => {
          backArmed = false;
          setToast("");
        }, 1800);
      }
      armBack();
    };
    let backArmed = false;
    window.addEventListener("popstate", onBack);

    // Size the canvas from a ResizeObserver instead of measuring layout every frame.
    let cssW = 1;
    let cssH = 1;
    const measure = () => {
      const rect = canvas.getBoundingClientRect();
      cssW = Math.max(1, rect.width);
      cssH = Math.max(1, rect.height);
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(canvas);

    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target?.closest("button, input, a")) return;
      if (e.code !== "Space" && e.code !== "Enter") {
        if (e.key === "Escape" && phaseRef.current === "play") go("pause");
        if (e.key.toLowerCase() === "m") toggleMute();
        return;
      }
      e.preventDefault();
      const now = phaseRef.current;
      if (now === "menu" || (now === "dead" && showResultRef.current)) startRun();
      else if (now === "play") {
        unlock();
        worldRef.current?.requestFlip();
      } else if (now === "pause") go("play");
    };
    window.addEventListener("keydown", onKey);

    const loop = (now: number) => {
      if (!alive) return;
      const rawDt = (now - last) / 1000;
      const dt = Math.min(0.05, rawDt);
      last = now;
      const world = worldRef.current;
      const currentPhase = phaseRef.current;
      if (world) {
        const simulate = currentPhase === "play" || currentPhase === "menu" || currentPhase === "dead";
        if (simulate) {
          acc += dt;
          let steps = 0;
          const bot = currentPhase === "menu";
          while (acc >= STEP && steps < 5) {
            world.step(STEP, bot);
            acc -= STEP;
            steps++;
            consume(world, currentPhase);
          }
          if (steps === 5) acc = 0;
        }
        if (currentPhase === "play" && !world.player.alive) finishRun();
        if (currentPhase === "menu" && !world.player.alive) bootWorld();
        if (currentPhase === "play" && coachRef.current === 3) {
          coachTime += dt;
          if (coachTime > 5.6) {
            coachTime = 0;
            advanceCoach(0);
          }
        } else {
          coachTime = 0;
        }
        const sfx = sfxRef.current;
        if (sfx && (currentPhase === "play" || currentPhase === "menu")) {
          const speedT = (world.climb() - CLIMB_MIN) / (CLIMB_MAX - CLIMB_MIN);
          const intensity = currentPhase === "menu" ? 0.08 : Math.min(1, world.combo / 8 * 0.72 + speedT * 0.4);
          sfx.pump(intensity);
        }
        hudAcc += dt;
        if (currentPhase === "play" && hudAcc > 0.1) {
          hudAcc = 0;
          setHud({
            score: world.score,
            combo: world.combo,
            mult: multiplier(world.combo).toLocaleString("ru-RU", { maximumFractionDigits: 2 }),
            coins: world.runCoins,
          });
        }
      }

      lookRef.current.tune(rawDt);
      // Cap the backing store: 3x phones gain little but pay ~2.2x fill-rate versus 2x.
      const dprCap = lookRef.current.quality < 0.5 ? 1.25 : 2;
      const dpr = Math.min(dprCap, window.devicePixelRatio || 1);
      const bw = Math.max(1, Math.round(cssW * dpr));
      const bh = Math.max(1, Math.round(cssH * dpr));
      if (canvas.width !== bw || canvas.height !== bh) {
        canvas.width = bw;
        canvas.height = bh;
      }
      const focus = currentPhase === "menu" || currentPhase === "skins" || currentPhase === "quests" ? 0.56 : 0.3;
      const skin = skinById(saveRef.current?.selected ?? "plyuh");
      if (worldRef.current) {
        lookRef.current.frame(ctx, worldRef.current, skin, bw, bh, dpr, dt, focus, reducedRef.current);
      }
      raf = requestAnimationFrame(loop);
    };

    function consume(world: World, currentPhase: Phase) {
      const playing = currentPhase === "play";
      const look = lookRef.current;
      const sfx = sfxRef.current;
      if (playing) {
        for (const ev of world.events) {
          if (ev.t === "flip") {
            sfx?.flip();
            look.burst(ev.x, ev.y, "#7dffe0", 10, 90);
            look.ring(ev.x, ev.y, "#7dffe0", 30);
            look.trauma = Math.min(1, look.trauma + 0.08);
            if (coachRef.current === 1) advanceCoach(2);
            if (coachRef.current === 3) advanceCoach(0);
          } else if (ev.t === "land") {
            sfx?.land();
            look.burst(ev.x, ev.y, "#f6efe4", 8, 70);
            look.ring(ev.x, ev.y, "#f6efe4", 40);
            look.trauma = Math.min(1, look.trauma + (reducedRef.current ? 0 : 0.18));
            if (coachRef.current === 2) advanceCoach(3);
          } else if (ev.t === "coin") {
            sfx?.coin();
            look.burst(ev.x, ev.y, "#ffc24b", ev.risk ? 14 : 8, 110);
            look.ring(ev.x, ev.y, "#ffc24b", 26);
            look.popup(ev.x, ev.y, ev.risk ? "+серия" : "+1", "#ffc24b");
          } else if (ev.t === "combo") {
            sfx?.combo(ev.n);
            look.popup(ev.x, ev.y + 18, `×${multiplier(ev.n).toLocaleString("ru-RU", { maximumFractionDigits: 2 })}`, "#ffc24b");
            if (ev.n === 4 || ev.n === 8 || ev.n === 12) look.flash = Math.min(0.8, look.flash + 0.25);
          } else if (ev.t === "die") {
            sfx?.die();
            look.burst(ev.x, ev.y, "#ff6a45", 26, 160);
            look.ring(ev.x, ev.y, "#ff6a45", 90);
            look.trauma = 1;
            look.flash = 0.7;
          }
        }
      }
      world.events.length = 0;
    }

    raf = requestAnimationFrame(loop);
    window.__flipfall = () => {
      const world = worldRef.current;
      return {
        phase: phaseRef.current,
        score: Math.floor(world?.score ?? 0),
        alive: world?.player.alive ?? false,
        y: world?.player.y ?? 0,
        combo: world?.combo ?? 0,
        coins: world?.runCoins ?? 0,
      };
    };
    return () => {
      alive = false;
      cancelAnimationFrame(raf);
      window.removeEventListener("keydown", onKey);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("pagehide", onVis);
      window.removeEventListener("popstate", onBack);
      ro.disconnect();
      reducedMq.removeEventListener("change", onReduce);
      delete window.__flipfall;
    };
    // The loop closes over the latest handlers via refs. Mount once.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function onPointerDown(e: React.PointerEvent) {
    const target = e.target as HTMLElement;
    if (target.closest("button, a, input")) return;
    if (phaseRef.current !== "play") return;
    e.preventDefault();
    unlock();
    worldRef.current?.requestFlip();
  }

  const skin = skinById(save?.selected ?? "plyuh");
  const claimable = save?.quests.filter((q) => !q.claimed && q.progress >= q.target) ?? [];

  return (
    <main className="shell">
      <div className="stage" onPointerDown={onPointerDown} onContextMenu={(e) => e.preventDefault()}>
        <canvas ref={canvasRef} />
        {!save ? (
          <div className="absolute inset-0 grid place-items-center">
            <h1 className="font-display text-5xl text-foam">FLIPFALL</h1>
          </div>
        ) : null}

        {save && (phase === "menu" || phase === "skins" || phase === "quests") ? (
          <header className="safe-top pointer-events-none absolute inset-x-0 top-0 z-10 px-5 pt-7 text-center title-in">
            <p className="text-xs font-medium tracking-widest text-mint">ОДНО КАСАНИЕ</p>
            <h1 className="font-display text-5xl leading-none text-foam">FLIPFALL</h1>
          </header>
        ) : null}

        {save && phase === "menu" ? (
          <div className="absolute inset-x-0 bottom-0 z-10">
            <div className="dock rise">
              <div className="flex items-center justify-between text-sm text-foam">
                <span>рекорд {fmt(save.best)}</span>
                <span className="inline-flex items-center gap-1 text-gold">
                  <Coins className="size-4" aria-hidden="true" />
                  {fmt(save.coins)}
                </span>
              </div>
              <button
                type="button"
                className="btn-primary h-14 w-full rounded-full bg-coral text-lg font-bold text-ink"
                onClick={startRun}
              >
                ИГРАТЬ
              </button>
              <p className="text-center text-sm text-muted">Касание в любом месте меняет гравитацию</p>
              <div className="grid grid-cols-3 gap-2">
                <button type="button" className="btn-ghost h-12 rounded-full border border-line bg-deep text-sm text-foam" onClick={() => go("skins")}>
                  Герой
                </button>
                <button type="button" className="btn-ghost h-12 rounded-full border border-line bg-deep text-sm text-foam" onClick={() => go("quests")}>
                  Цели
                </button>
                <button type="button" className="icon-btn size-12 justify-self-end" aria-label={save.muted ? "Включить звук" : "Выключить звук"} onClick={toggleMute}>
                  {save.muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
                </button>
              </div>
            </div>
          </div>
        ) : null}

        {save && phase === "play" ? (
          <>
            <div className="safe-top pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-2 px-3 pt-3">
              <div className="pt-1">
                <p className="font-display text-3xl leading-none text-foam">{fmt(hud.score)}</p>
                <p className="text-xs text-muted">рекорд {fmt(Math.max(save.best, hud.score))}</p>
                <p className="text-xs text-gold">монеты {fmt(hud.coins)}</p>
              </div>
              <div className="pt-1 text-center">
                {hud.combo > 0 ? (
                  <>
                    <p key={hud.combo} className="pop font-display text-2xl leading-none text-gold">×{hud.mult}</p>
                    <p className="text-xs text-mint">серия {hud.combo}</p>
                  </>
                ) : (
                  <p className="text-xs text-muted">серия ×1</p>
                )}
              </div>
              <div className="pointer-events-auto flex gap-2">
                <button type="button" className="icon-btn" aria-label={save.muted ? "Включить звук" : "Выключить звук"} onClick={toggleMute}>
                  {save.muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
                </button>
                <button type="button" className="icon-btn" aria-label="Пауза" onClick={() => go("pause")}>
                  <Pause className="size-5" />
                </button>
              </div>
            </div>
            {coach > 0 ? (
              <div className="fade-in safe-top-24 pointer-events-none absolute inset-x-4 top-24 z-10 rounded-2xl border border-line bg-ink/80 px-4 py-3 text-center text-sm text-foam">
                {COACH[coach]}
              </div>
            ) : null}
          </>
        ) : null}

        {save && phase === "pause" ? (
          <div className="sheet fade-in absolute inset-0 z-20 grid place-items-center px-6">
            <div className="flex w-full max-w-xs flex-col gap-3 text-center">
              <h2 className="font-display text-4xl text-foam">Пауза</h2>
              <button type="button" className="btn-primary h-14 rounded-full bg-coral text-lg font-bold text-ink" onClick={() => go("play")}>
                <span className="inline-flex items-center gap-2">
                  <Play className="size-5" />
                  Дальше
                </span>
              </button>
              <button type="button" className="btn-ghost h-12 rounded-full border border-line text-foam" onClick={toMenu}>
                В меню
              </button>
            </div>
          </div>
        ) : null}

        {save && phase === "dead" && showResult && death ? (
          <div className="fade-in absolute inset-0 z-20 flex items-end bg-ink/45">
            <div className="dock rise w-full">
              {death.record ? <p className="pop text-center text-sm font-bold tracking-wide text-gold">Новый рекорд</p> : null}
              <p className="text-center text-sm text-muted">{death.reason}</p>
              <p className="pop text-center font-display text-5xl leading-none text-foam">{fmt(death.score)}</p>
              <div className="flex justify-between text-sm text-foam">
                <span>рекорд {fmt(death.best)}</span>
                <span className="text-gold">монеты +{fmt(death.coins)}</span>
                <span>серия {death.combo}</span>
              </div>
              {death.coins === 0 ? (
                <p className="text-center text-xs text-muted">Золотые капли на рискованных дугах дают монеты</p>
              ) : null}
              {claimable.length > 0 ? (
                <button type="button" className="btn-ghost h-11 rounded-full border border-gold text-sm text-gold" onClick={() => onClaim(claimable[0]!.id)}>
                  Забрать награду за цель +{claimable[0]!.reward}
                </button>
              ) : null}
              <button type="button" className="btn-primary h-14 rounded-full bg-coral text-lg font-bold text-ink" onClick={startRun}>
                ИГРАТЬ СНОВА
              </button>
              <button type="button" className="btn-ghost h-12 rounded-full border border-line text-foam" onClick={toMenu}>
                В меню
              </button>
            </div>
          </div>
        ) : null}

        {save && phase === "skins" ? (
          <div className="sheet fade-in safe-top absolute inset-0 z-20 flex flex-col px-4 pt-4">
            <div className="flex items-center gap-3">
              <button type="button" className="icon-btn" aria-label="Назад" onClick={() => go("menu")}>
                <ChevronLeft className="size-5" />
              </button>
              <div>
                <h2 className="font-display text-3xl leading-none">Герои</h2>
                <p className="text-sm text-gold">{fmt(save.coins)} монет</p>
              </div>
            </div>
            <p className="mt-3 text-sm text-muted">Только внешность. На скорость не влияют.</p>
            <div className="mt-4 grid flex-1 grid-cols-2 content-start gap-3 overflow-y-auto pb-6">
              {SKINS.map((item) => {
                const owned = save.unlocked.includes(item.id);
                const selected = save.selected === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => pickSkin(item.id)}
                    className={`btn-ghost skin-card flex flex-col items-start gap-1 rounded-2xl border p-3 text-left ${selected ? "border-mint bg-deep" : "border-line bg-deep/70"}`}
                  >
                    <span className="grid size-14 place-items-center rounded-full" style={{ background: item.deep }}>
                      <span className="size-10 rounded-full" style={{ background: item.body }} />
                    </span>
                    <span className="font-medium text-foam">{item.name}</span>
                    <span className="text-xs text-muted">{item.blurb}</span>
                    <span className="text-sm text-gold">
                      {selected ? "Выбран" : owned ? "Выбрать" : `${fmt(item.price)} монет`}
                    </span>
                  </button>
                );
              })}
            </div>
            {toast ? <p className="pb-4 text-center text-sm text-coral">{toast}</p> : null}
          </div>
        ) : null}

        {save && phase === "quests" ? (
          <div className="sheet fade-in safe-top absolute inset-0 z-20 flex flex-col px-4 pt-4">
            <div className="flex items-center gap-3">
              <button type="button" className="icon-btn" aria-label="Назад" onClick={() => go("menu")}>
                <ChevronLeft className="size-5" />
              </button>
              <div>
                <h2 className="font-display text-3xl leading-none">Цели дня</h2>
                <p className="text-sm text-muted">{save.questsDate}</p>
              </div>
            </div>
            <ul className="mt-4 flex flex-col gap-3 overflow-y-auto pb-6">
              {save.quests.map((quest) => {
                const done = quest.progress >= quest.target;
                const width = `${Math.round((quest.progress / quest.target) * 100)}%`;
                return (
                  <li key={quest.id} className="rounded-2xl border border-line bg-deep p-4">
                    <div className="flex items-baseline justify-between gap-3">
                      <p className="font-medium text-foam">{quest.title}</p>
                      <p className="text-sm text-gold">+{quest.reward}</p>
                    </div>
                    <p className="mt-1 text-xs text-muted">
                      {Math.min(quest.progress, quest.target)} / {quest.target}
                    </p>
                    <div className="mt-2 h-2 overflow-hidden rounded-full bg-ink">
                      <div className="bar h-full rounded-full bg-mint" style={{ width }} />
                    </div>
                    {quest.claimed ? (
                      <p className="mt-3 text-sm text-muted">Забрано</p>
                    ) : (
                      <button
                        type="button"
                        disabled={!done}
                        className="btn-primary mt-3 h-11 w-full rounded-full bg-coral text-sm font-bold text-ink disabled:opacity-40"
                        onClick={() => onClaim(quest.id)}
                      >
                        {done ? "Забрать" : "В процессе"}
                      </button>
                    )}
                  </li>
                );
              })}
            </ul>
          </div>
        ) : null}

        {toast && phase !== "skins" ? (
          <p className="toast pointer-events-none absolute inset-x-6 bottom-28 z-30 rounded-full border border-line bg-ink/90 px-4 py-2 text-center text-sm text-foam">
            {toast}
          </p>
        ) : null}

        <span className="sr-only">{skin.name}</span>
      </div>
    </main>
  );
}
