import {
  CLIMB_MIN,
  COYOTE,
  CRUMBLE_DIST,
  K,
  LEFT0,
  PROBE_PAD,
  R,
  RIGHT0,
  SLIP_COYOTE,
  SPIKE_IN,
  WORLD_W,
  climbSpeed,
  multiplier,
  type Side,
} from "./constants";
import {
  CHUNKS,
  POCKET,
  pickChunk,
  mulberry32,
  type ChunkDef,
  type Kind,
  type RotorDef,
} from "./level";

export type LiveSeg = {
  uid: number;
  side: Side;
  y0: number;
  y1: number;
  kind: Kind;
  inset: number;
  move: number;
  moveSpeed: number;
  movePhase: number;
  crumbleDist: number;
  ridden: number;
  dead: boolean;
};

export type LiveRotor = RotorDef & { y: number };
export type LiveCoin = { x: number; y: number; risk: boolean; taken: boolean };
export type Block = { y0: number; h: number; safe: boolean; id: string };

export type WorldEvent =
  | { t: "flip"; x: number; y: number; dir: Side }
  | { t: "land"; x: number; y: number }
  | { t: "coin"; x: number; y: number; risk: boolean }
  | { t: "combo"; x: number; y: number; n: number }
  | { t: "die"; x: number; y: number; reason: string };

export type Hint = { x: number; y: number; side: Side };

type Probe = {
  ok: boolean;
  x: number;
  y: number;
  kind: Kind | null;
  coin: boolean;
};

export type Player = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  grav: Side;
  side: Side;
  grounded: boolean;
  alive: boolean;
  flipCd: number;
  rot: number;
  rotV: number;
  squash: number;
  landT: number;
  segUid: number;
  takeoffDanger: boolean;
  airFlip: boolean;
  grabbedAir: boolean;
  diedReason: string;
  wobble: number;
};

export type WorldOpts = {
  seed?: number;
  tutorial?: boolean;
  climbLock?: number;
  preset?: ChunkDef[];
  time0?: number;
  startSide?: Side;
};

let uid = 1;

function distPointSeg(
  px: number,
  py: number,
  ax: number,
  ay: number,
  bx: number,
  by: number,
) {
  const abx = bx - ax;
  const aby = by - ay;
  const ab2 = abx * abx + aby * aby || 1;
  let t = ((px - ax) * abx + (py - ay) * aby) / ab2;
  t = Math.max(0, Math.min(1, t));
  const dx = px - (ax + abx * t);
  const dy = py - (ay + aby * t);
  return Math.hypot(dx, dy);
}

export class World {
  player: Player;
  segs: LiveSeg[] = [];
  rotors: LiveRotor[] = [];
  coins: LiveCoin[] = [];
  blocks: Block[] = [];
  events: WorldEvent[] = [];
  hint: Hint | null = null;
  time: number;
  score = 0;
  combo = 0;
  maxCombo = 0;
  lastComboAt = -10;
  idle = 0;
  flips = 0;
  runCoins = 0;
  top = 0;
  prevId = "";
  sinceSafe = 0;
  finite: boolean;
  script: string[];
  climbLock: number;
  rng: () => number;
  wantFlip = false;
  buffer = 0;
  safeNow = false;

  constructor(opts: WorldOpts = {}) {
    this.rng = mulberry32(opts.seed ?? 1);
    this.climbLock = opts.climbLock ?? 0;
    this.time = opts.time0 ?? 0;
    this.finite = !!opts.preset;
    this.script = opts.tutorial ? ["flip-wide", "spikes", "pocket"] : [];
    this.player = {
      x: 70,
      y: 100,
      vx: 0,
      vy: 0,
      grav: -1,
      side: -1,
      grounded: true,
      alive: true,
      flipCd: 0,
      rot: 0,
      rotV: 0,
      squash: 0,
      landT: 0,
      segUid: -1,
      takeoffDanger: false,
      airFlip: false,
      grabbedAir: false,
      diedReason: "",
      wobble: 0,
    };
    if (opts.preset) {
      for (const def of opts.preset) this.spawn(def);
    } else {
      this.spawn(POCKET);
      this.ensure();
    }
    this.place(opts.startSide ?? -1);
  }

  climb() {
    return this.climbLock || climbSpeed(Math.max(0, this.player.y));
  }

  flipSpeed() {
    return this.climb() * K;
  }

  requestFlip() {
    if (!this.player.alive) return;
    if (this.player.flipCd <= 0) this.wantFlip = true;
    else this.buffer = 0.16;
  }

  faceOf(seg: LiveSeg, time = this.time) {
    const base = seg.side === -1 ? LEFT0 : RIGHT0;
    let x = seg.side === -1 ? base + seg.inset : base - seg.inset;
    if (seg.move) {
      const wave = Math.sin(time * seg.moveSpeed + seg.movePhase) * 0.5 + 0.5;
      const inward = wave * seg.move;
      x += seg.side === -1 ? inward : -inward;
    }
    return x;
  }

  restX(side: Side, face: number) {
    return side === -1 ? face + R : face - R;
  }

  private covers(seg: LiveSeg, y: number, pad: number) {
    return y >= seg.y0 - pad && y < seg.y1 + pad;
  }

  landableAt(side: Side, y: number, pad = 0): LiveSeg | null {
    let best: LiveSeg | null = null;
    let score = -1;
    for (const seg of this.segs) {
      if (seg.dead || seg.side !== side || seg.kind === "spike") continue;
      if (!this.covers(seg, y, pad)) continue;
      const s = seg.kind === "boost" ? 3 : seg.kind === "crumble" ? 2 : 1;
      if (s > score) {
        best = seg;
        score = s;
      }
    }
    return best;
  }

  spikeAt(side: Side, y: number): LiveSeg | null {
    for (const seg of this.segs) {
      if (seg.dead || seg.side !== side || seg.kind !== "spike") continue;
      if (y >= seg.y0 && y < seg.y1) return seg;
    }
    return null;
  }

  safeRideUntil(side: Side, y: number) {
    let cursor = y;
    const cap = y + 560;
    let guard = 0;
    while (cursor < cap && guard++ < 16) {
      if (this.spikeAt(side, cursor)) return cursor;
      const seg = this.landableAt(side, cursor, 0.5);
      if (!seg) return cursor;
      let end = seg.y1;
      if (seg.kind === "crumble") {
        end = Math.min(end, cursor + Math.max(0, seg.crumbleDist - seg.ridden));
      }
      if (end <= cursor + 0.25) return cursor;
      const next = end + 0.5;
      if (this.spikeAt(side, next)) return Math.min(end, this.spikeAt(side, next)?.y0 ?? end);
      if (!this.landableAt(side, next, 0.5) && !this.spikeAt(side, next)) return end;
      cursor = next;
    }
    return cap;
  }

  private rotorHit(x: number, y: number, time: number) {
    for (const rot of this.rotors) {
      const a = rot.phase + time * rot.omega;
      const dx = Math.cos(a) * rot.len;
      const dy = Math.sin(a) * rot.len;
      const d = distPointSeg(x, y, rot.x - dx, rot.y - dy, rot.x + dx, rot.y + dy);
      if (d < R + rot.thick) return true;
    }
    return false;
  }

  private spikeTouch(x: number, y: number) {
    for (const seg of this.segs) {
      if (seg.dead || seg.kind !== "spike") continue;
      if (y < seg.y0 - 4 || y > seg.y1 + 4) continue;
      const face = this.faceOf(seg);
      if (seg.side === -1) {
        if (x - R <= face + SPIKE_IN && x >= face - 36) return true;
      } else if (x + R >= face - SPIKE_IN && x <= face + 36) return true;
    }
    return false;
  }

  probeFlip(target: Side, fromY = this.player.y, fromX = this.player.x): Probe {
    const climb = this.climb();
    const vx = target * climb * K;
    const vy = climb;
    let x = fromX;
    let y = fromY;
    let hitRotor = false;
    let hitSpike = false;
    let coin = false;
    const h = 1 / 180;
    for (let n = 0; n < 180; n++) {
      const px = x;
      const py = y;
      const pt = this.time + (n + 1) * h;
      x += vx * h;
      y += vy * h;
      if (this.rotorHit(x, y, pt)) hitRotor = true;
      if (this.spikeTouch(x, y)) hitSpike = true;
      for (const c of this.coins) {
        if (c.taken) continue;
        if ((c.x - x) * (c.x - x) + (c.y - y) * (c.y - y) < 22 * 22) coin = true;
      }
      const hit = this.crossLand(target, px, py, x, y, pt, PROBE_PAD);
      if (hit) {
        const remain = this.safeRideUntil(target, hit.y + 1) - hit.y;
        return {
          ok: !hitRotor && !hitSpike && remain > 48,
          x: hit.rest,
          y: hit.y,
          kind: hit.seg.kind,
          coin,
        };
      }
      if (x < 2 || x > WORLD_W - 2) break;
    }
    return { ok: false, x, y, kind: null, coin };
  }

  private crossLand(
    side: Side,
    px: number,
    py: number,
    x: number,
    y: number,
    time: number,
    pad: number,
  ) {
    let best: { seg: LiveSeg; y: number; rest: number } | null = null;
    for (const seg of this.segs) {
      if (seg.dead || seg.side !== side || seg.kind === "spike") continue;
      const rest = this.restX(side, this.faceOf(seg, time));
      const crossed = side === -1 ? px >= rest && x <= rest : px <= rest && x >= rest;
      if (!crossed) continue;
      const denom = x - px || 1;
      const frac = Math.max(0, Math.min(1, (rest - px) / denom));
      const cy = py + (y - py) * frac;
      if (cy < seg.y0 - pad || cy > seg.y1 + pad) continue;
      if (!best || cy < best.y) best = { seg, y: cy, rest };
    }
    return best;
  }

  private place(side: Side) {
    const y = 110;
    const seg = this.landableAt(side, y, 8);
    const face = seg ? this.faceOf(seg) : side === -1 ? LEFT0 : RIGHT0;
    this.player.x = this.restX(side, face);
    this.player.y = y;
    this.player.vx = 0;
    this.player.vy = this.climb();
    this.player.grav = side;
    this.player.side = side;
    this.player.grounded = true;
    this.player.alive = true;
    this.player.segUid = seg?.uid ?? -1;
    this.player.flipCd = 0.08;
  }

  private spawn(def: ChunkDef) {
    const base = this.top;
    for (const s of def.segs) {
      this.segs.push({
        uid: uid++,
        side: s.side,
        y0: base + s.y0,
        y1: base + s.y1,
        kind: s.kind,
        inset: s.inset ?? 0,
        move: s.move ?? 0,
        moveSpeed: s.moveSpeed ?? 0,
        movePhase: s.movePhase ?? 0,
        crumbleDist: s.crumbleDist ?? CRUMBLE_DIST,
        ridden: 0,
        dead: false,
      });
    }
    for (const r of def.rotors ?? []) {
      this.rotors.push({ ...r, y: base + r.y });
    }
    for (const c of def.coins ?? []) {
      this.coins.push({ x: c.x, y: base + c.y, risk: !!c.risk, taken: false });
    }
    this.blocks.push({ y0: base, h: def.h, safe: !!def.safe, id: def.id });
    this.top = base + def.h;
    this.prevId = def.id;
    if (def.safe) this.sinceSafe = 0;
    else this.sinceSafe++;
  }

  private ensure() {
    if (this.finite) return;
    while (this.top < this.player.y + 1800) {
      let def: ChunkDef | undefined;
      if (this.script.length) {
        const id = this.script.shift()!;
        def = id === "pocket" ? POCKET : CHUNKS.find((c) => c.id === id);
      }
      if (!def) {
        def = pickChunk(this.player.y, this.rng, this.prevId, this.sinceSafe >= 4);
      }
      this.spawn(def);
    }
    const keep = this.player.y - 700;
    this.segs = this.segs.filter((s) => s.y1 > keep);
    this.rotors = this.rotors.filter((r) => r.y > keep - 200);
    this.coins = this.coins.filter((c) => !c.taken && c.y > keep);
    this.blocks = this.blocks.filter((b) => b.y0 + b.h > keep);
  }

  private die(reason: string) {
    if (!this.player.alive) return;
    this.player.alive = false;
    this.player.grounded = false;
    this.player.diedReason = reason;
    this.player.squash = 0.85;
    this.player.rotV = 7.5 * this.player.grav;
    this.events.push({
      t: "die",
      x: this.player.x,
      y: this.player.y,
      reason,
    });
  }

  private doFlip() {
    const p = this.player;
    const ride = this.safeRideUntil(p.side, p.y) - p.y;
    p.takeoffDanger = ride < 280;
    p.airFlip = true;
    p.grabbedAir = false;
    p.grounded = false;
    p.grav = (p.grav === -1 ? 1 : -1) as Side;
    p.vx = p.grav * this.flipSpeed();
    p.vy = this.climb();
    p.flipCd = 0.12;
    p.rotV = p.grav * 9.5;
    p.squash = 0.48;
    p.landT = 0;
    this.flips++;
    this.wantFlip = false;
    this.buffer = 0;
    this.events.push({ t: "flip", x: p.x, y: p.y, dir: p.grav });
  }

  private onLand(seg: LiveSeg) {
    const p = this.player;
    const meaningful = p.takeoffDanger || seg.kind !== "solid" || p.grabbedAir;
    if (p.airFlip && meaningful) {
      const gap = this.time - this.lastComboAt;
      if (this.combo === 0 || gap < 2.15) this.combo += 1;
      else this.combo = 1;
      this.lastComboAt = this.time;
      this.idle = 0;
      if (this.combo > this.maxCombo) this.maxCombo = this.combo;
      this.score += 14 * multiplier(this.combo);
      this.events.push({ t: "combo", x: p.x, y: p.y, n: this.combo });
    }
    p.airFlip = false;
    p.grabbedAir = false;
    this.events.push({ t: "land", x: p.x, y: p.y });
  }

  private tryLand(px: number, py: number, x: number, y: number) {
    const p = this.player;
    const side = p.grav;
    if (this.spikeCross(side, px, py, x, y)) {
      this.die("spike");
      return true;
    }
    const hit = this.crossLand(side, px, py, x, y, this.time, COYOTE);
    if (!hit) return false;
    p.x = hit.rest;
    p.y = Math.max(hit.seg.y0, Math.min(hit.seg.y1 - 0.5, hit.y));
    p.vx = 0;
    p.grounded = true;
    p.side = side;
    p.segUid = hit.seg.uid;
    p.squash = -0.5;
    p.landT = 0.14;
    p.rotV = 0;
    this.onLand(hit.seg);
    return true;
  }

  private spikeCross(side: Side, px: number, py: number, x: number, y: number) {
    for (const seg of this.segs) {
      if (seg.dead || seg.side !== side || seg.kind !== "spike") continue;
      const face = this.faceOf(seg);
      const tip = side === -1 ? face + SPIKE_IN : face - SPIKE_IN;
      const crossed = side === -1 ? px >= tip && x <= tip : px <= tip && x >= tip;
      if (!crossed) continue;
      const denom = x - px || 1;
      const frac = Math.max(0, Math.min(1, (tip - px) / denom));
      const cy = py + (y - py) * frac;
      if (cy >= seg.y0 - 6 && cy <= seg.y1 + 6) return true;
    }
    return false;
  }

  private collect(x: number, y: number, airborne: boolean) {
    for (const c of this.coins) {
      if (c.taken) continue;
      if (Math.hypot(c.x - x, c.y - y) > R + 13) continue;
      c.taken = true;
      this.runCoins++;
      this.score += 24 * multiplier(Math.max(this.combo, 1));
      if (airborne) this.player.grabbedAir = true;
      this.events.push({ t: "coin", x: c.x, y: c.y, risk: c.risk });
    }
  }

  private updateHint() {
    const p = this.player;
    if (!p.alive || !p.grounded) {
      this.hint = null;
      return;
    }
    const opp: Side = p.grav === -1 ? 1 : -1;
    const now = this.probeFlip(opp);
    if (!now.ok) {
      this.hint = null;
      return;
    }
    const ride = this.safeRideUntil(p.side, p.y) - p.y;
    let closing = ride < 360;
    if (!closing) {
      const ahead = p.y + 150;
      const seg = this.landableAt(p.side, ahead, 4);
      if (!seg) closing = true;
      else {
        const later = this.probeFlip(opp, ahead, this.restX(p.side, this.faceOf(seg)));
        if (!later.ok || (now.kind !== "solid" && later.kind !== now.kind)) closing = true;
      }
    }
    this.hint = closing ? { x: now.x, y: now.y, side: opp } : null;
  }

  step(dt: number, bot = false) {
    const p = this.player;
    this.time += dt;
    if (!p.alive) {
      p.squash += (0.15 - p.squash) * Math.min(1, dt * 4);
      p.rot += p.rotV * dt;
      p.rotV *= Math.exp(-dt * 1.15);
      return;
    }

    if (p.flipCd > 0) p.flipCd = Math.max(0, p.flipCd - dt);
    if (this.buffer > 0) {
      this.buffer = Math.max(0, this.buffer - dt);
      if (p.flipCd <= 0) this.wantFlip = true;
    }

    if (bot && p.grounded && p.flipCd <= 0) {
      const opp: Side = p.grav === -1 ? 1 : -1;
      const probe = this.probeFlip(opp);
      const ride = this.safeRideUntil(p.side, p.y) - p.y;
      if (probe.ok && ride < 250) this.wantFlip = true;
    }

    if (this.wantFlip && p.flipCd <= 0) this.doFlip();

    if (p.grounded) {
      const boostSeg = this.landableAt(p.side, p.y, 2);
      const boost = boostSeg?.kind === "boost" ? 1.45 : 1;
      const vy = this.climb() * boost;
      p.vy = vy;
      p.y += vy * dt;
      if (this.spikeTouch(p.x, p.y) || this.spikeAt(p.side, p.y)) {
        this.die("spike");
      } else if (this.rotorHit(p.x, p.y, this.time)) {
        this.die("rotor");
      } else {
        let seg = this.landableAt(p.side, p.y, 0);
        if (!seg && p.segUid) {
          const prev = this.segs.find((s) => s.uid === p.segUid);
          if (
            prev &&
            !prev.dead &&
            prev.side === p.side &&
            p.y <= prev.y1 + SLIP_COYOTE &&
            p.y >= prev.y0 - 2
          ) {
            seg = prev;
          }
        }
        if (!seg) {
          p.grounded = false;
          p.airFlip = false;
          p.vx = p.grav * this.flipSpeed();
          p.vy = this.climb();
        } else {
          if (seg.kind === "crumble") {
            seg.ridden += vy * dt;
            if (seg.ridden >= seg.crumbleDist) {
              seg.dead = true;
              p.grounded = false;
              p.airFlip = false;
              p.vx = p.grav * this.flipSpeed();
            }
          }
          if (p.grounded) {
            p.segUid = seg.uid;
            p.x = this.restX(p.side, this.faceOf(seg));
            p.side = p.grav;
          }
        }
      }
    }

    if (!p.grounded && p.alive) {
      const dist = Math.hypot(p.grav * this.flipSpeed(), this.climb()) * dt;
      const n = Math.max(1, Math.ceil(dist / 5));
      const h = dt / n;
      for (let i = 0; i < n && p.alive && !p.grounded; i++) {
        const px = p.x;
        const py = p.y;
        p.vx = p.grav * this.flipSpeed();
        p.vy = this.climb();
        p.x += p.vx * h;
        p.y += p.vy * h;
        this.collect(p.x, p.y, true);
        if (this.tryLand(px, py, p.x, p.y)) break;
        if (this.spikeTouch(p.x, p.y)) {
          this.die("spike");
          break;
        }
        if (this.rotorHit(p.x, p.y, this.time)) {
          this.die("rotor");
          break;
        }
        if (p.x < 8 || p.x > WORLD_W - 8) {
          this.die("void");
          break;
        }
      }
    } else if (p.alive) {
      this.collect(p.x, p.y, false);
    }

    if (p.alive) {
      this.score += this.climb() * dt * 0.085 * multiplier(this.combo);
      this.safeNow = this.blocks.some(
        (b) => b.safe && p.y >= b.y0 + 20 && p.y <= b.y0 + b.h - 20,
      );
      if (p.grounded) {
        this.idle += dt;
        const limit = this.safeNow ? 3.2 : 2.15;
        if (this.idle > limit && this.combo > 0) this.combo = 0;
      }
      if (p.landT > 0) p.landT = Math.max(0, p.landT - dt);
      const edge = this.safeRideUntil(p.side, p.y) - p.y;
      p.wobble = p.grounded && edge < 70 ? 1 - edge / 70 : 0;
      const squashTarget = p.grounded ? (p.landT > 0 ? -0.48 : p.wobble * 0.08) : 0.42;
      p.squash += (squashTarget - p.squash) * (1 - Math.exp(-dt * 14));
      if (p.grounded) {
        const goal = Math.sin(this.time * 16) * p.wobble * 0.35;
        p.rot += (goal - p.rot) * Math.min(1, dt * 10);
      } else {
        p.rot += p.rotV * dt;
        p.rotV *= Math.exp(-dt * 1.4);
      }
      this.ensure();
      this.updateHint();
    }
  }
}

export function auditAll(): string[] {
  const errors: string[] = [];
  const climbs = [CLIMB_MIN, 280, 398];
  const phases = [0, 0.45, 0.9, 1.35, 1.8, 2.25];
  const defs = [POCKET, ...CHUNKS];
  for (const def of defs) {
    for (const side of [-1, 1] as const) {
      for (const climb of climbs) {
        const phaseSet = def.rotors?.length ? phases : [0];
        for (const ph of phaseSet) {
          const res = simulate(def, side, climb, ph);
          if (!res.ok) {
            errors.push(
              `${def.id} side ${side} climb ${climb} t0 ${ph}: ${res.reason} y=${res.y.toFixed(0)}`,
            );
          }
        }
      }
    }
  }
  return errors;
}

export function simulate(def: ChunkDef, side: Side, climb: number, time0: number) {
  const world = new World({
    seed: 7,
    preset: [def, POCKET],
    climbLock: climb,
    time0,
    startSide: side,
  });
  let guard = 0;
  while (world.player.alive && world.player.y < def.h + 160 && guard < 25000) {
    world.step(1 / 60, true);
    guard++;
  }
  if (!world.player.alive) {
    return { ok: false, reason: world.player.diedReason || "dead", y: world.player.y };
  }
  if (guard >= 25000) return { ok: false, reason: "stuck", y: world.player.y };
  return { ok: true, reason: "", y: world.player.y };
}
