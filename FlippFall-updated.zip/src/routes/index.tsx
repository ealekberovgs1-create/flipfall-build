import { createFileRoute } from "@tanstack/react-router";
import { Flipfall } from "@/game/Flipfall";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Flipfall />;
}
